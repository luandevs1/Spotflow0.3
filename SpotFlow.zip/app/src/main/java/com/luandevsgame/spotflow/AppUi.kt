package com.luandevsgame.spotflow

import android.Manifest
import android.content.ComponentName
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext


@Composable
fun SpotFlowTheme(content: @Composable () -> Unit) = MaterialTheme(
    colorScheme = darkColorScheme(primary = Green, onPrimary = Color.Black, background = Bg, surface = Bg,
        onBackground = Color.White, onSurface = Color.White, surfaceVariant = Card, onSurfaceVariant = Muted)
        .let { if (IsAero) it.copy(outline = Color.White.copy(0.55f)) else it },
    content = content)

class PlayerState {
    var title by mutableStateOf(""); var artist by mutableStateOf("")
    var playing by mutableStateOf(false); var hasItem by mutableStateOf(false)
    var mediaId by mutableStateOf<Long?>(null); var art by mutableStateOf<Uri?>(null); var shuffle by mutableStateOf(false); var repeat by mutableIntStateOf(0)
    fun sync(p: Player) {
        title = p.mediaMetadata.title?.toString() ?: ""; artist = p.mediaMetadata.artist?.toString() ?: ""
        mediaId = p.currentMediaItem?.mediaId?.toLongOrNull(); art = p.mediaMetadata.artworkUri; hasItem = p.mediaItemCount > 0; playing = p.isPlaying
        shuffle = p.shuffleModeEnabled; repeat = p.repeatMode
    }
}

enum class Sort(val label: String) { NAME("Nome"), ARTIST("Artista"), ALBUM("Álbum"), ADDED("Adicionadas") }

@Composable
fun AppRoot() {
    val ctx = LocalContext.current
    var controller by remember { mutableStateOf<MediaController?>(null) }
    DisposableEffect(Unit) {
        val f = MediaController.Builder(ctx, SessionToken(ctx, ComponentName(ctx, PlaybackService::class.java))).buildAsync()
        f.addListener({ controller = try { f.get() } catch (e: Exception) { null } }, ContextCompat.getMainExecutor(ctx))
        onDispose { MediaController.releaseFuture(f); controller = null }
    }
    val ps = remember { PlayerState() }
    DisposableEffect(controller) {
        val c = controller
        if (c == null) onDispose { } else {
            val l = object : Player.Listener { override fun onEvents(player: Player, events: Player.Events) = ps.sync(player) }
            c.addListener(l); ps.sync(c)
            onDispose { c.removeListener(l) }
        }
    }
    val perm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
    var granted by remember { mutableStateOf(ContextCompat.checkSelfPermission(ctx, perm) == PackageManager.PERMISSION_GRANTED) }
    val notif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        granted = it
        if (it && Build.VERSION.SDK_INT >= 33) notif.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    var songs by remember { mutableStateOf<List<Song>>(emptyList()) }
    LaunchedEffect(granted) { if (granted) songs = withContext(Dispatchers.IO) { loadSongs(ctx) } }
    val scope = rememberCoroutineScope()
    val refresh: () -> Unit = { scope.launch { if (granted) songs = withContext(Dispatchers.IO) { loadSongs(ctx) } } }
    val playList: (List<Song>, Int) -> Unit = { l, i ->
        controller?.let { c -> c.setMediaItems(l.map { it.toItem() }, i, 0L); c.prepare(); c.play() }
    }
    val playStream: (MediaItem) -> Unit = { item -> controller?.let { c -> c.setMediaItem(item); c.prepare(); c.play() } }
    var tab by remember { mutableIntStateOf(0) }
    // A bolha da barra anima na hora; o conteúdo da nova aba entra logo depois (com fade),
    // para a composição pesada da tela não competir com a animação da barra.
    var shown by remember { mutableIntStateOf(0) }
    val fade = remember { Animatable(1f) }
    LaunchedEffect(tab) {
        if (shown != tab) {
            delay(130)
            shown = tab
            fade.snapTo(0f)
            fade.animateTo(1f, tween(180))
        }
    }
    var showFull by remember { mutableStateOf(false) }

    var bottomPx by remember { mutableIntStateOf(0) }
    val bottomDp = with(LocalDensity.current) { bottomPx.toDp() }
    val navItems = listOf("Início" to Icons.Filled.Home, "Pesquisar" to Icons.Filled.Search, "Biblioteca" to Icons.Filled.LibraryMusic,
        "Downloads" to Icons.Filled.Download, "Ajustes" to Icons.Filled.Settings)

    Surface(Modifier.fillMaxSize(), color = if (IsAero) Color.Transparent else Bg, contentColor = Color.White) {
    Box(Modifier.fillMaxSize()) {
        if (IsAero) AeroBackground()
        CompositionLocalProvider(LocalBottomPad provides bottomDp) {
            Box(Modifier.fillMaxSize().graphicsLayer { alpha = fade.value }) {
                when (shown) {
                    0 -> HomeScreen(granted, songs, { launcher.launch(perm) }, playList)
                    1 -> SearchScreen()
                    2 -> LibraryScreen(granted, songs, { launcher.launch(perm) }, playList)
                    3 -> DownloadsScreen(refresh, playStream)
                    else -> SettingsScreen()
                }
            }
        }
        Column(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().onSizeChanged { bottomPx = it.height }
                .padding(horizontal = 12.dp).padding(bottom = 10.dp, top = 6.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val mini = controller
            if (ps.hasItem && mini != null) MiniPlayer(ps, mini) { showFull = true }
            GlassNavBar(navItems, tab, { tab = it })
        }
        val full = controller
        if (full != null) NowPlayingOverlay(showFull, ps, full) { showFull = false }
    }
    }
}

@Composable
fun Cover(model: Any?, size: Int, modifier: Modifier = Modifier) {
    Box(modifier.size(size.dp).clip(RoundedCornerShape(10.dp)).background(Card), contentAlignment = Alignment.Center) {
        Icon(Icons.Filled.MusicNote, null, tint = Muted)
        AsyncImage(model, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
    }
}

@Composable
fun NeedPermission(onAsk: () -> Unit) = Column(Modifier.fillMaxSize().padding(32.dp), Arrangement.Center, Alignment.CenterHorizontally) {
    Text("Encontre suas músicas", fontSize = 22.sp, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(8.dp))
    Text("Permita o acesso aos arquivos de áudio para listar a música do aparelho. Nada é enviado para servidores.", color = Muted)
    Spacer(Modifier.height(16.dp))
    Button(onAsk, colors = ButtonDefaults.buttonColors(containerColor = Green)) { Text("Permitir acesso") }
}

@Composable
fun HomeScreen(granted: Boolean, songs: List<Song>, onAsk: () -> Unit, play: (List<Song>, Int) -> Unit) {
    if (!granted) { NeedPermission(onAsk); return }
    if (songs.isEmpty()) {
        Column(Modifier.fillMaxSize().padding(32.dp), Arrangement.Center, Alignment.CenterHorizontally) {
            Text("Nenhuma música encontrada", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text("Copie arquivos de áudio para a pasta Música do aparelho e reabra o app.", color = Muted)
        }
        return
    }
    val recent = remember(songs) { songs.sortedByDescending { it.added }.take(15) }
    val albums = remember(songs) { songs.distinctBy { it.albumId }.take(15) }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp, 16.dp, 16.dp, 16.dp + LocalBottomPad.current), verticalArrangement = Arrangement.spacedBy(20.dp)) {
        item { Text("Início", fontSize = 28.sp, fontWeight = FontWeight.Bold) }
        item { Button({ play(songs.shuffled(), 0) }, colors = ButtonDefaults.buttonColors(containerColor = Green)) {
            Icon(Icons.Filled.Shuffle, null); Spacer(Modifier.width(8.dp)); Text("Tocar tudo em aleatório") } }
        item { Shelf("Adicionados recentemente", recent) { play(recent, it) } }
        item { Shelf("Álbuns da biblioteca", albums) { play(songs.filter { s -> s.albumId == albums[it].albumId }, 0) } }
    }
}

@Composable
fun Shelf(title: String, list: List<Song>, onClick: (Int) -> Unit) = Column {
    Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(10.dp))
    LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        itemsIndexed(list) { i, s ->
            Column(Modifier.width(140.dp).clickable { onClick(i) }) {
                SongCover(s.id, Modifier.size(140.dp))
                Text(s.title, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 6.dp))
                Text(s.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, color = Muted, fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun LibraryScreen(granted: Boolean, songs: List<Song>, onAsk: () -> Unit, play: (List<Song>, Int) -> Unit) {
    if (!granted) { NeedPermission(onAsk); return }
    var q by remember { mutableStateOf("") }
    var sort by remember { mutableStateOf(Sort.ADDED) }
    val list = remember(songs, q, sort) {
        val f = songs.filter { q.isBlank() || it.title.contains(q, true) || it.artist.contains(q, true) || it.album.contains(q, true) }
        when (sort) {
            Sort.NAME -> f.sortedBy { it.title.lowercase() }
            Sort.ARTIST -> f.sortedBy { it.artist.lowercase() }
            Sort.ALBUM -> f.sortedBy { it.album.lowercase() }
            Sort.ADDED -> f.sortedByDescending { it.added }
        }
    }
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Text("Biblioteca", fontSize = 28.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 16.dp))
        OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth().padding(vertical = 8.dp), singleLine = true, placeholder = { Text("Pesquisar na biblioteca") })
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(Sort.values().toList()) { s -> GlassChip(sort == s, { sort = s }) { Text(s.label) } }
        }
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(top = 8.dp, bottom = 8.dp + LocalBottomPad.current)) {
            itemsIndexed(list) { i, s ->
                Row(Modifier.fillMaxWidth().clickable { play(list, i) }.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    SongCover(s.id, Modifier.size(52.dp))
                    Column(Modifier.padding(start = 12.dp)) {
                        Text(s.title, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(s.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, color = Muted, fontSize = 13.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun SearchScreen() {
    var q by remember { mutableStateOf("") }
    var hits by remember { mutableStateOf<List<Hit>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var searched by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val uri = LocalUriHandler.current
    fun go() {
        if (q.isBlank()) return
        loading = true; error = null
        scope.launch {
            try { hits = withContext(Dispatchers.IO) { searchMusicBrainz(q) }; searched = true }
            catch (e: Exception) { hits = emptyList(); error = "Não foi possível pesquisar: ${e.message ?: "verifique a conexão"}" }
            loading = false
        }
    }
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Text("Pesquisar", fontSize = 28.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 16.dp))
        OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth().padding(vertical = 8.dp), singleLine = true,
            placeholder = { Text("Música, artista ou álbum") },
            trailingIcon = { IconButton({ go() }) { Icon(Icons.Filled.Search, "Pesquisar") } })
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Green)
        error?.let { Text(it, color = Color(0xFFFF6B6B)) }
        if (searched && hits.isEmpty() && error == null && !loading) Text("Nenhum resultado.", color = Muted)
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(top = 8.dp, bottom = 8.dp + LocalBottomPad.current)) {
            items(hits) { h ->
                Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Cover(h.releaseId?.let { "https://coverartarchive.org/release/$it/front-250" }, 56)
                    Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                        Text(h.title, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(h.artist + (h.album?.let { " • $it" } ?: ""), maxLines = 1, overflow = TextOverflow.Ellipsis, color = Muted, fontSize = 13.sp)
                        Text("MusicBrainz" + (h.durationMs?.let { " • %d:%02d".format(it / 60000, it / 1000 % 60) } ?: ""), color = Green, fontSize = 11.sp)
                    }
                    TextButton({ uri.openUri("https://musicbrainz.org/recording/${h.id}") }) { Text("Abrir", color = Green) }
                }
            }
        }
    }
}

@Composable
fun MiniPlayer(ps: PlayerState, c: MediaController, onOpen: () -> Unit) {
    var progress by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(ps.playing, ps.title) {
        while (true) {
            val d = c.duration
            progress = if (d > 0) (c.currentPosition.toFloat() / d).coerceIn(0f, 1f) else 0f
            delay(500)
        }
    }
    val shape = RoundedCornerShape(30.dp)
    Column(Modifier.fillMaxWidth().glassPanel(shape, 0.82f)) {
        Row(
            Modifier.fillMaxWidth().liquidPress(shape, pressScale = 0.985f, onTap = onOpen).padding(start = 10.dp, end = 6.dp, top = 8.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            PlayerCover(ps, Modifier.size(46.dp), 14.dp)
            Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                Text(ps.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 14.sp)
                Text(ps.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, color = Muted, fontSize = 12.sp)
            }
            LiquidIconButton(Icons.Filled.SkipPrevious, "Anterior", { c.seekToPrevious() })
            LiquidIconButton(if (ps.playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, "Tocar/Pausar",
                { if (c.isPlaying) c.pause() else c.play() }, size = 48.dp, iconSize = 28.dp, filled = true)
            LiquidIconButton(Icons.Filled.SkipNext, "Próxima", { c.seekToNext() })
        }
        Box(Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, bottom = 8.dp).height(3.dp).clip(RoundedCornerShape(50)).background(Color.White.copy(0.14f))) {
            Box(Modifier.fillMaxWidth(progress).fillMaxHeight().background(Green))
        }
    }
}
