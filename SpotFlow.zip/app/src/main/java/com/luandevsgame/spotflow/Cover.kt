package com.luandevsgame.spotflow

import android.content.ContentUris
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.os.Build
import android.provider.MediaStore
import android.util.LruCache
import android.util.Size
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Capa embutida em CADA arquivo (cada música tem a sua), com cache em memória. */
object CoverCache {
    private val cache = object : LruCache<Long, Bitmap>(24 * 1024 * 1024) {
        override fun sizeOf(key: Long, value: Bitmap): Int = value.byteCount
    }
    private val none = java.util.Collections.synchronizedSet(HashSet<Long>())

    fun peek(id: Long): Bitmap? = cache.get(id)

    fun load(ctx: Context, id: Long, px: Int = 512): Bitmap? {
        cache.get(id)?.let { return it }
        if (id in none) return null
        val uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)
        var bmp: Bitmap? = null
        try {
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(ctx, uri)
                val data = r.embeddedPicture
                if (data != null) bmp = decode(data, px)
            } finally { r.release() }
        } catch (e: Exception) { }
        if (bmp == null && Build.VERSION.SDK_INT >= 29) {
            try { bmp = ctx.contentResolver.loadThumbnail(uri, Size(px, px), null) } catch (e: Exception) { }
        }
        val result = bmp
        if (result != null) cache.put(id, result) else none.add(id)
        return result
    }

    private fun decode(b: ByteArray, px: Int): Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(b, 0, b.size, o)
        var s = 1
        while (o.outWidth / (s * 2) >= px && o.outHeight / (s * 2) >= px) s *= 2
        val o2 = BitmapFactory.Options().apply { inSampleSize = s }
        return BitmapFactory.decodeByteArray(b, 0, b.size, o2)
    }
}

@Composable
fun SongCover(id: Long?, modifier: Modifier, corner: Dp = 10.dp) {
    val ctx = LocalContext.current
    val bmp by produceState<Bitmap?>(initialValue = id?.let { CoverCache.peek(it) }, key1 = id) {
        value = if (id == null) null else withContext(Dispatchers.IO) { CoverCache.load(ctx, id) }
    }
    Box(modifier.clip(RoundedCornerShape(corner)).background(Card), contentAlignment = Alignment.Center) {
        Icon(Icons.Filled.MusicNote, null, tint = Muted)
        val b = bmp
        if (b != null) Image(b.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
    }
}

/** Capa do que está tocando: embutida (arquivo local) ou a imagem da fonte online (streaming). */
@Composable
fun PlayerCover(ps: PlayerState, modifier: Modifier, corner: Dp = 10.dp) {
    if (ps.mediaId != null) SongCover(ps.mediaId, modifier, corner)
    else Box(modifier.clip(RoundedCornerShape(corner)).background(Card), contentAlignment = Alignment.Center) {
        Icon(Icons.Filled.MusicNote, null, tint = Muted)
        AsyncImage(ps.art, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
    }
}
