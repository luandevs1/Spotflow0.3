package com.luandevsgame.spotflow

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.AnimationSpec
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.awaitHorizontalTouchSlopOrCancellation
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.drag
import androidx.compose.foundation.gestures.horizontalDrag
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.ProvideTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.onClick
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs
import kotlin.math.roundToInt

/** Altura (barra + mini player flutuantes) que as listas devem reservar no final. */
val LocalBottomPad = compositionLocalOf { 0.dp }

private val GlassEdge: Brush
    get() = if (IsAero) Brush.linearGradient(listOf(Color.White.copy(0.90f), Color.White.copy(0.18f), Color.White.copy(0.55f)))
        else Brush.linearGradient(listOf(Color.White.copy(0.55f), Color.White.copy(0.06f), Color.White.copy(0.30f)))

/** Brilho Aero: metade de cima mais clara com borda dura, como os botões de vidro do Windows 7. */
private fun gloss(a: Float): Brush = Brush.verticalGradient(
    0f to Color.White.copy(a), 0.5f to Color.White.copy(a * 0.30f),
    0.5f to Color.Transparent, 1f to Color.White.copy(0.10f))

/** Painel de vidro (barra, mini player): fundo escuro translúcido + brilho no topo + borda especular. */
fun Modifier.glassPanel(shape: Shape, baseAlpha: Float = 0.80f): Modifier =
    if (IsAero) this
        .shadow(16.dp, shape, ambientColor = Color(0xFF001830), spotColor = Color(0xFF001830))
        .clip(shape)
        .background(hsvColor(AccentHue, 0.85f, 0.42f).copy(alpha = baseAlpha))
        .background(gloss(0.34f))
        .border(1.5.dp, GlassEdge, shape)
    else this
        .shadow(14.dp, shape, ambientColor = Color.Black, spotColor = Color.Black)
        .clip(shape)
        .background(Color(0xFF16181B).copy(alpha = baseAlpha))
        .background(Brush.verticalGradient(listOf(Color.White.copy(0.16f), Color.White.copy(0.03f))))
        .border(1.dp, GlassEdge, shape)

/**
 * Toque "líquido": encolhe com mola (quica ao soltar) e um brilho se espalha a partir do ponto tocado.
 */
@Composable
fun Modifier.liquidPress(
    shape: Shape,
    enabled: Boolean = true,
    pressScale: Float = 0.92f,
    glow: Color = Color.White,
    onTap: () -> Unit
): Modifier {
    var pressed by remember { mutableStateOf(false) }
    var touch by remember { mutableStateOf(Offset.Zero) }
    val scale by animateFloatAsState(if (pressed) pressScale else 1f, spring(dampingRatio = 0.45f, stiffness = 520f), label = "lp-scale")
    val glowA by animateFloatAsState(if (pressed) 1f else 0f, tween(if (pressed) 120 else 480), label = "lp-glow")
    val cb by rememberUpdatedState(onTap)
    return this
        .graphicsLayer { scaleX = scale; scaleY = scale }
        .clip(shape)
        .drawBehind {
            if (glowA > 0.01f) drawRect(
                Brush.radialGradient(
                    listOf(glow.copy(alpha = 0.38f * glowA), Color.Transparent),
                    center = touch, radius = size.maxDimension * 0.9f
                )
            )
        }
        .pointerInput(enabled) {
            if (!enabled) return@pointerInput
            detectTapGestures(
                onPress = { o -> touch = o; pressed = true; tryAwaitRelease(); pressed = false },
                onTap = { cb() }
            )
        }
        .semantics(mergeDescendants = true) {
            role = Role.Button
            if (enabled) onClick { cb(); true }
        }
}

/** Botão de ícone com vidro líquido. [filled] = bolha de vidro tingida com a cor de destaque. */
@Composable
fun LiquidIconButton(
    icon: ImageVector,
    description: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 44.dp,
    iconSize: Dp = 24.dp,
    tint: Color = Color.White,
    filled: Boolean = false
) {
    val accent = Orb
    val a1 = if (IsAero) 0.95f else 0.75f
    val a2 = if (IsAero) 0.70f else 0.40f
    val bg = if (filled) Modifier.background(Brush.verticalGradient(listOf(accent.copy(a1), accent.copy(a2))), CircleShape)
        .then(if (IsAero) Modifier.background(gloss(0.42f), CircleShape) else Modifier)
        .border(1.dp, GlassEdge, CircleShape) else Modifier
    Box(
        modifier.size(size)
            .liquidPress(CircleShape, pressScale = if (filled) 0.88f else 0.80f, onTap = onClick)
            .then(bg),
        contentAlignment = Alignment.Center
    ) { Icon(icon, description, Modifier.size(iconSize), tint = if (filled) Color.White else tint) }
}

/** Chip de vidro: selecionado fica tingido com a cor de destaque e brilha. */
@Composable
fun GlassChip(
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    content: @Composable () -> Unit
) {
    val shape = RoundedCornerShape(50)
    val accent = Orb
    val sel by animateFloatAsState(if (selected) 1f else 0f, spring(dampingRatio = 0.7f, stiffness = 300f), label = "chip-sel")
    val t = sel.coerceIn(0f, 1f)
    val top = lerp(Color.White.copy(0.12f), accent.copy(0.60f), t)
    val bottom = lerp(Color.White.copy(0.04f), accent.copy(0.30f), t)
    Box(
        modifier.alpha(if (enabled) 1f else 0.40f)
            .liquidPress(shape, enabled, pressScale = 0.90f, onTap = onClick)
            .background(Brush.verticalGradient(listOf(top, bottom)))
            .then(if (IsAero) Modifier.background(gloss(0.22f + 0.20f * t)) else Modifier)
            .border(1.dp, GlassEdge, shape)
            .padding(horizontal = 16.dp, vertical = 9.dp),
        contentAlignment = Alignment.Center
    ) {
        CompositionLocalProvider(LocalContentColor provides Color.White.copy(alpha = 0.82f + 0.18f * t)) {
            ProvideTextStyle(MaterialTheme.typography.labelLarge) { content() }
        }
    }
}

/** Interruptor estilo iOS 26: bolha de vidro que estica ao tocar e quica ao trocar de lado. Aceita arrastar. */
@Composable
fun GlassSwitch(checked: Boolean, onChange: (Boolean) -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true) {
    val accent = Orb
    val haptic = LocalHapticFeedback.current
    val density = LocalDensity.current
    var pressed by remember { mutableStateOf(false) }
    val checkedNow by rememberUpdatedState(checked)
    val cb by rememberUpdatedState(onChange)
    val trackW = 62.dp; val trackH = 34.dp; val pad = 3.dp
    val t by animateFloatAsState(if (checked) 1f else 0f, spring(dampingRatio = 0.55f, stiffness = 380f), label = "sw-t")
    val thumbW by animateDpAsState(if (pressed) 46.dp else 34.dp, spring(dampingRatio = 0.55f, stiffness = 500f), label = "sw-w")
    val thumbH by animateDpAsState(if (pressed) 30.dp else 28.dp, spring(dampingRatio = 0.55f, stiffness = 500f), label = "sw-h")
    val glassA by animateFloatAsState(if (pressed) 0.62f else 0.96f, tween(160), label = "sw-a")
    val tc = t.coerceIn(0f, 1f)
    val trackColor = lerp(Color.White.copy(0.18f), accent.copy(0.92f), tc)
    val travel = trackW - pad * 2 - thumbW
    Box(
        modifier.alpha(if (enabled) 1f else 0.45f).size(trackW, trackH)
            .clip(CircleShape)
            .background(trackColor)
            .border(1.dp, Brush.verticalGradient(listOf(Color.White.copy(0.35f), Color.White.copy(0.06f))), CircleShape)
            .pointerInput(enabled) {
                if (!enabled) return@pointerInput
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    pressed = true
                    var target: Boolean? = null
                    val slop = awaitHorizontalTouchSlopOrCancellation(down.id) { c, _ -> c.consume() }
                    if (slop != null) {
                        target = slop.position.x > size.width / 2f
                        horizontalDrag(slop.id) { c -> target = c.position.x > size.width / 2f; c.consume() }
                    } else {
                        val ch = currentEvent.changes.firstOrNull { it.id == down.id }
                        if (ch == null || !ch.pressed) target = !checkedNow
                    }
                    pressed = false
                    val tg = target
                    if (tg != null && tg != checkedNow) {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        cb(tg)
                    }
                }
            }
            .semantics { role = Role.Switch; if (enabled) onClick { cb(!checkedNow); true } },
        contentAlignment = Alignment.CenterStart
    ) {
        Box(
            Modifier
                .offset { IntOffset((with(density) { (pad + travel * t).toPx() }).roundToInt(), 0) }
                .size(thumbW, thumbH)
                .shadow(4.dp, CircleShape, ambientColor = Color.Black, spotColor = Color.Black)
                .clip(CircleShape)
                .background(Brush.verticalGradient(listOf(Color.White.copy(glassA), Color.White.copy(glassA * 0.80f))))
                .border(1.dp, Brush.verticalGradient(listOf(Color.White, Color.White.copy(0.35f))), CircleShape)
        )
    }
}

/**
 * Slider de vidro: trilho que engrossa e bolha de vidro que estica (e fica translúcida) ao arrastar.
 * Com [steps] > 0 encaixa nos passos, vibra de leve e mostra os pontinhos.
 */
@Composable
fun GlassSlider(
    value: Float,
    onValueChange: (Float) -> Unit,
    modifier: Modifier = Modifier,
    valueRange: ClosedFloatingPointRange<Float> = 0f..1f,
    steps: Int = 0,
    enabled: Boolean = true,
    onValueChangeFinished: (() -> Unit)? = null
) {
    val accent = Green
    val haptic = LocalHapticFeedback.current
    val density = LocalDensity.current
    var widthPx by remember { mutableFloatStateOf(0f) }
    var pressed by remember { mutableStateOf(false) }
    val curValue by rememberUpdatedState(value)
    val onChange by rememberUpdatedState(onValueChange)
    val onFinish by rememberUpdatedState(onValueChangeFinished)
    val span = (valueRange.endInclusive - valueRange.start).coerceAtLeast(1e-6f)
    val frac = ((value - valueRange.start) / span).coerceIn(0f, 1f)
    val moveSpec: AnimationSpec<Float> = if (pressed) snap() else spring(dampingRatio = 0.8f, stiffness = 420f)
    val shown by animateFloatAsState(frac, moveSpec, label = "sl-frac")
    val thumbW by animateDpAsState(if (pressed) 46.dp else 30.dp, spring(dampingRatio = 0.55f, stiffness = 480f), label = "sl-w")
    val thumbH by animateDpAsState(if (pressed) 32.dp else 22.dp, spring(dampingRatio = 0.55f, stiffness = 480f), label = "sl-h")
    val trackH by animateDpAsState(if (pressed) 12.dp else 8.dp, spring(dampingRatio = 0.6f, stiffness = 480f), label = "sl-th")
    val glassA by animateFloatAsState(if (pressed) 0.58f else 0.96f, tween(160), label = "sl-a")
    val thumbWpx = with(density) { thumbW.toPx() }
    val thumbWState by rememberUpdatedState(thumbWpx)
    val travel = (widthPx - thumbWpx).coerceAtLeast(0f)
    val thumbX = travel * shown

    Box(
        modifier.fillMaxWidth().height(40.dp).alpha(if (enabled) 1f else 0.45f)
            .onSizeChanged { widthPx = it.width.toFloat() }
            .pointerInput(enabled, steps, valueRange.start, valueRange.endInclusive) {
                if (!enabled) return@pointerInput
                var changed = false
                fun upd(x: Float) {
                    val tw = thumbWState
                    val tr = (widthPx - tw).coerceAtLeast(1f)
                    var f = ((x - tw / 2f) / tr).coerceIn(0f, 1f)
                    if (steps > 0) f = (f * (steps + 1)).roundToInt() / (steps + 1f)
                    val nv = valueRange.start + f * span
                    if (abs(nv - curValue) > 1e-4f) {
                        if (steps > 0) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        changed = true
                        onChange(nv)
                    }
                }
                awaitEachGesture {
                    changed = false
                    val down = awaitFirstDown(requireUnconsumed = false)
                    pressed = true
                    val slop = awaitHorizontalTouchSlopOrCancellation(down.id) { c, _ -> c.consume() }
                    if (slop != null) {
                        upd(slop.position.x)
                        horizontalDrag(slop.id) { c -> upd(c.position.x); c.consume() }
                    } else {
                        val ch = currentEvent.changes.firstOrNull { it.id == down.id }
                        if (ch == null || !ch.pressed) upd(down.position.x)
                    }
                    pressed = false
                    if (changed) onFinish?.invoke()
                }
            }
            .semantics { role = Role.Button; contentDescription = "Controle deslizante" },
        contentAlignment = Alignment.CenterStart
    ) {
        // trilho
        Box(
            Modifier.fillMaxWidth().height(trackH).clip(CircleShape)
                .background(Color.White.copy(0.13f))
                .border(0.5.dp, Color.White.copy(0.18f), CircleShape)
        )
        // parte preenchida
        Box(
            Modifier.width(with(density) { (thumbX + thumbWpx / 2f).toDp() }).height(trackH).clip(CircleShape)
                .background(Brush.horizontalGradient(listOf(accent.copy(0.70f), accent)))
        )
        // pontinhos dos passos
        if (steps in 1..12) Box(Modifier.fillMaxWidth().height(trackH).drawBehind {
            val r = 2.dp.toPx()
            for (i in 0..steps + 1) {
                val x = thumbWpx / 2f + (size.width - thumbWpx) * i / (steps + 1f)
                drawCircle(Color.White.copy(0.55f), r, Offset(x, size.height / 2f))
            }
        })
        // bolha de vidro
        Box(
            Modifier
                .offset { IntOffset(thumbX.roundToInt(), 0) }
                .size(thumbW, thumbH)
                .shadow(5.dp, CircleShape, ambientColor = Color.Black, spotColor = Color.Black)
                .clip(CircleShape)
                .background(Brush.verticalGradient(listOf(Color.White.copy(glassA), Color.White.copy(glassA * 0.78f))))
                .border(1.dp, Brush.verticalGradient(listOf(Color.White, Color.White.copy(0.30f))), CircleShape)
        )
    }
}

/**
 * Barra de navegação flutuante de vidro. A bolha desliza com mola e se estica; dá para arrastar entre as abas.
 * Durante a animação NADA é recomposto: posição, esticada e brilho dos ícones são lidos só na fase de desenho
 * (graphicsLayer), por isso fica fluida mesmo em build debug.
 */
@Composable
fun GlassNavBar(
    items: List<Pair<String, ImageVector>>,
    current: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val haptic = LocalHapticFeedback.current
    val n = items.size
    val shape = RoundedCornerShape(34.dp)
    val bubbleShape = RoundedCornerShape(28.dp)
    var preview by remember { mutableStateOf<Int?>(null) }
    var pressed by remember { mutableStateOf(false) }
    val select by rememberUpdatedState(onSelect)
    val target = preview ?: current
    val orb = Orb
    val aero = IsAero
    val pos = remember { Animatable(current.toFloat()) }
    LaunchedEffect(target) { pos.animateTo(target.toFloat(), spring(dampingRatio = 0.72f, stiffness = 420f)) }
    val press by animateFloatAsState(if (pressed) 1.06f else 1f, spring(dampingRatio = 0.6f, stiffness = 500f), label = "nav-p")

    Box(modifier.fillMaxWidth().glassPanel(shape).padding(6.dp)) {
        BoxWithConstraints(Modifier.fillMaxWidth().height(60.dp)) {
            val itemW = maxWidth / n
            // bolha
            Box(
                Modifier.width(itemW).fillMaxHeight()
                    .graphicsLayer {
                        translationX = pos.value * size.width
                        val stretch = minOf(abs(target - pos.value), 1f) * 0.18f
                        scaleX = press + stretch
                        scaleY = press - stretch * 0.4f
                    }
                    .clip(bubbleShape)
                    .background(Brush.verticalGradient(listOf(orb.copy(0.60f), orb.copy(0.26f))))
                    .then(if (aero) Modifier.background(gloss(0.40f)) else Modifier)
                    .border(1.dp, GlassEdge, bubbleShape)
            )
            Row(
                Modifier.fillMaxSize().pointerInput(n) {
                    awaitEachGesture {
                        val down = awaitFirstDown(requireUnconsumed = false)
                        fun idx(x: Float) = (x / (size.width / n.toFloat())).toInt().coerceIn(0, n - 1)
                        pressed = true
                        var last = idx(down.position.x)
                        preview = last
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        drag(down.id) { c ->
                            val j = idx(c.position.x)
                            if (j != last) { last = j; preview = j; haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove) }
                            c.consume()
                        }
                        pressed = false
                        preview = null
                        select(last)
                    }
                }
            ) {
                items.forEachIndexed { i, (label, icon) ->
                    Column(
                        Modifier.weight(1f).fillMaxHeight()
                            .graphicsLayer { alpha = 0.68f + 0.32f * (1f - minOf(abs(pos.value - i), 1f)) }
                            .semantics { role = Role.Tab; selected = i == current; onClick { select(i); true } },
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(icon, label, Modifier.size(24.dp), tint = Color.White)
                        Spacer(Modifier.height(2.dp))
                        Text(label, color = Color.White, fontSize = 11.sp, maxLines = 1)
                    }
                }
            }
        }
    }
}
