package com.luandevsgame.spotflow

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.draw.blur
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import kotlinx.coroutines.delay

private fun fmt(ms: Long): String = "%d:%02d".format(ms / 60000, ms / 1000 % 60)

@Composable
fun NowPlayingOverlay(visible: Boolean, ps: PlayerState, c: MediaController, onClose: () -> Unit) {
    BackHandler(enabled = visible, onBack = onClose)
    AnimatedVisibility(visible = visible, enter = slideInVertically { it }, exit = slideOutVertically { it }) {
        NowPlayingScreen(ps, c, onClose)
    }
}

@Composable
fun NowPlayingScreen(ps: PlayerState, c: MediaController, onClose: () -> Unit) {
    var pos by remember { mutableFloatStateOf(0f) }
    var dragging by remember { mutableStateOf(false) }
    LaunchedEffect(ps.title) {
        while (true) { if (!dragging) pos = c.currentPosition.toFloat(); delay(500) }
    }
    val dur = c.duration.coerceAtLeast(1L).toFloat()

    Box(
        Modifier.fillMaxSize().background(Color(0xFF0C0C0C))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { }
    ) {
        // fundo: capa desfocada (o blur só tem efeito no Android 12+; antes disso fica a capa suave com escurecimento)
        PlayerCover(ps, Modifier.fillMaxSize().blur(60.dp).alpha(0.50f), 0.dp)
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0x55000000), Color(0xEE000000)))))
        Column(
            Modifier.fillMaxSize().padding(horizontal = 24.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                LiquidIconButton(Icons.Filled.KeyboardArrowDown, "Fechar", onClose, size = 44.dp,
                    modifier = Modifier.glassPanel(CircleShape, 0.35f))
                Text("Tocando agora", modifier = Modifier.weight(1f), textAlign = TextAlign.Center, color = Muted, fontSize = 13.sp)
                Spacer(Modifier.width(44.dp))
            }
            Spacer(Modifier.height(20.dp))
            PlayerCover(ps, Modifier.fillMaxWidth().aspectRatio(1f).shadow(24.dp, RoundedCornerShape(24.dp)), 24.dp)
            Spacer(Modifier.height(28.dp))
            Text(ps.title, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
            Text(ps.artist, color = Muted, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
            Spacer(Modifier.height(20.dp))
            GlassSlider(
                value = pos.coerceIn(0f, dur),
                onValueChange = { dragging = true; pos = it },
                valueRange = 0f..dur,
                onValueChangeFinished = { c.seekTo(pos.toLong()); dragging = false },
                modifier = Modifier.fillMaxWidth()
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(fmt(pos.toLong()), color = Muted, fontSize = 12.sp)
                Text(fmt(c.duration.coerceAtLeast(0L)), color = Muted, fontSize = 12.sp)
            }
            Spacer(Modifier.height(16.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                LiquidIconButton(Icons.Filled.Shuffle, "Aleatório", { c.shuffleModeEnabled = !c.shuffleModeEnabled },
                    tint = if (ps.shuffle) Green else Muted)
                LiquidIconButton(Icons.Filled.SkipPrevious, "Anterior", { c.seekToPrevious() }, size = 56.dp, iconSize = 36.dp)
                LiquidIconButton(if (ps.playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, "Tocar/Pausar",
                    { if (c.isPlaying) c.pause() else c.play() }, size = 76.dp, iconSize = 42.dp, filled = true)
                LiquidIconButton(Icons.Filled.SkipNext, "Próxima", { c.seekToNext() }, size = 56.dp, iconSize = 36.dp)
                LiquidIconButton(if (ps.repeat == Player.REPEAT_MODE_ONE) Icons.Filled.RepeatOne else Icons.Filled.Repeat, "Repetir", {
                    c.repeatMode = when (c.repeatMode) {
                        Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                        Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                        else -> Player.REPEAT_MODE_OFF
                    }
                }, tint = if (ps.repeat == Player.REPEAT_MODE_OFF) Muted else Green)
            }
        }
    }
}
