package com.luandevsgame.spotflow

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.unit.dp

/** true quando o tema Frutiger Aero está ligado. Lê estado do Compose, então a tela atualiza sozinha ao trocar. */
val IsAero: Boolean get() = Prefs.themeStyle == 1

fun hsvColor(h: Float, s: Float, v: Float): Color =
    Color(android.graphics.Color.HSVToColor(floatArrayOf(h, s, v)))

/** Matiz (0..360) de cada cor de destaque, calculado uma vez. */
private val HUES: List<Float> by lazy {
    Prefs.accents.map { a ->
        val hsv = FloatArray(3)
        android.graphics.Color.colorToHSV(a.second.toArgb(), hsv)
        hsv[0]
    }
}

val AccentHue: Float get() = HUES[Prefs.accent.coerceIn(0, HUES.size - 1)]
private val BaseAccent: Color get() = Prefs.accents[Prefs.accent.coerceIn(0, Prefs.accents.size - 1)].second

/** Cor de destaque para textos, barras e ícones. No Aero vira uma versão clara e brilhante da cor escolhida. */
val Green: Color get() = if (IsAero) hsvColor(AccentHue, 0.36f, 1f) else BaseAccent

/** Cor "cheia" para bolhas e botões preenchidos (no Aero é mais profunda, para o ícone branco aparecer bem). */
val Orb: Color get() = if (IsAero) hsvColor(AccentHue, 0.85f, 0.85f) else BaseAccent

val Bg: Color get() = if (IsAero) hsvColor(AccentHue, 0.90f, 0.28f) else Color(0xFF0A0A0A)
val Card: Color get() = if (IsAero) Color.White.copy(0.16f) else Color(0xFF1C1C1C)
val Muted: Color get() = if (IsAero) Color.White.copy(0.80f) else Color(0xFFB3B3B3)

private class AeroBubble(val x: Float, val y: Float, val r: Float, val a: Float)

private val AERO_BUBBLES = listOf(
    AeroBubble(0.86f, 0.10f, 46f, 0.90f), AeroBubble(0.12f, 0.22f, 22f, 0.70f),
    AeroBubble(0.70f, 0.36f, 70f, 0.55f), AeroBubble(0.20f, 0.52f, 54f, 0.60f),
    AeroBubble(0.90f, 0.66f, 30f, 0.80f), AeroBubble(0.35f, 0.78f, 84f, 0.45f),
    AeroBubble(0.78f, 0.88f, 38f, 0.70f)
)

/** Fundo Frutiger Aero: céu em degradê na cor de destaque, brilho no topo e bolhas de vidro. Desenhado uma vez (estático). */
@Composable
fun AeroBackground() {
    val h = AccentHue
    Canvas(Modifier.fillMaxSize()) {
        drawRect(Brush.verticalGradient(listOf(hsvColor(h, 0.60f, 0.86f), hsvColor(h, 0.82f, 0.60f), hsvColor(h, 0.92f, 0.26f))))
        drawRect(Brush.radialGradient(listOf(Color.White.copy(0.42f), Color.Transparent),
            center = Offset(size.width * 0.18f, -size.height * 0.04f), radius = size.width * 1.15f))
        drawRect(Brush.radialGradient(listOf(hsvColor(h, 0.45f, 1f).copy(0.30f), Color.Transparent),
            center = Offset(size.width * 0.5f, size.height * 1.02f), radius = size.width * 0.95f))
        AERO_BUBBLES.forEach { b ->
            val c = Offset(size.width * b.x, size.height * b.y)
            val r = b.r.dp.toPx()
            drawCircle(brush = Brush.radialGradient(listOf(Color.White.copy(0.02f), Color.White.copy(0.22f * b.a)), center = c, radius = r),
                radius = r, center = c)
            drawCircle(color = Color.White.copy(0.45f * b.a), radius = r, center = c, style = Stroke(1.5.dp.toPx()))
            drawArc(color = Color.White.copy(0.60f * b.a), startAngle = 200f, sweepAngle = 55f, useCenter = false,
                topLeft = Offset(c.x - r * 0.78f, c.y - r * 0.78f), size = Size(r * 1.56f, r * 1.56f),
                style = Stroke(r * 0.10f, cap = StrokeCap.Round))
        }
    }
}
