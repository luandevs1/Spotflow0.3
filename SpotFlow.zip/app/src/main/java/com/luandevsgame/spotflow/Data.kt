package com.luandevsgame.spotflow

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import android.provider.MediaStore.Audio.Media as M
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class Song(val id: Long, val title: String, val artist: String, val album: String,
                val durationMs: Long, val added: Long, val albumId: Long) {
    val uri: Uri get() = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)
    val art: Uri get() = ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"), albumId)
    fun toItem(): MediaItem = MediaItem.Builder().setMediaId(id.toString()).setUri(uri)
        .setMediaMetadata(MediaMetadata.Builder().setTitle(title).setArtist(artist).setAlbumTitle(album).setArtworkUri(art).build())
        .build()
}

fun loadSongs(ctx: Context): List<Song> {
    val out = ArrayList<Song>()
    val proj = arrayOf(M._ID, M.TITLE, M.ARTIST, M.ALBUM, M.DURATION, M.DATE_ADDED, M.ALBUM_ID)
    ctx.contentResolver.query(M.EXTERNAL_CONTENT_URI, proj, "${M.IS_MUSIC} != 0 AND ${M.DURATION} > 30000", null, "${M.DATE_ADDED} DESC")?.use { c ->
        while (c.moveToNext()) {
            val artist = c.getString(2)?.takeIf { it != "<unknown>" } ?: "Artista desconhecido"
            out += Song(c.getLong(0), c.getString(1) ?: "Sem título", artist, c.getString(3) ?: "", c.getLong(4), c.getLong(5), c.getLong(6))
        }
    }
    return out
}

data class Hit(val id: String, val title: String, val artist: String, val album: String?, val durationMs: Long?, val releaseId: String?)

/** Pesquisa de metadados no MusicBrainz (API pública, sem chave). Lança exceção em caso de falha. */
fun searchMusicBrainz(q: String): List<Hit> {
    val url = URL("https://musicbrainz.org/ws/2/recording?fmt=json&limit=25&query=" + URLEncoder.encode(q, "UTF-8"))
    val c = url.openConnection() as HttpURLConnection
    c.setRequestProperty("User-Agent", "SpotFlow/0.2 (projeto pessoal)")
    c.connectTimeout = 10000; c.readTimeout = 15000
    try {
        if (c.responseCode != 200) error("O servidor respondeu ${c.responseCode}")
        val arr = JSONObject(c.inputStream.bufferedReader().readText()).optJSONArray("recordings") ?: return emptyList()
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            val credits = o.optJSONArray("artist-credit")
            val artist = if (credits == null) "" else (0 until credits.length()).joinToString(", ") { credits.getJSONObject(it).optString("name") }
            val rel = o.optJSONArray("releases")?.optJSONObject(0)
            Hit(o.getString("id"), o.optString("title"), artist.ifBlank { "Artista desconhecido" },
                rel?.optString("title"), if (o.has("length")) o.optLong("length") else null, rel?.optString("id"))
        }
    } finally { c.disconnect() }
}
