# SpotFlow

Início/Pesquisar/Biblioteca/Downloads/Ajustes. Biblioteca local com capa por música, player Media3 (segundo plano e tela cheia),
pesquisa MusicBrainz, busca por nome nos Downloads em fontes que permitem download:
Internet Archive (sem chave) e Jamendo (API oficial; client_id gratuito do próprio usuário, em Ajustes).
Ouvir online no player do app, baixar com fila/progresso/cancelar. Equalizador, fade, timer, velocidade, cores.

Não inclui yt-dlp/youtubedl-android: GPL-3.0 e extração de plataformas que não autorizam download.
Versão 0.3 (Liquid Glass + tema Frutiger Aero). Compilar: GitHub > Actions > Build APK (ou baixe em Releases).
